<html>
        <head>
        <meta name="viewport" content="width=device-width, user-scalable =no">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="robots" content="noindex,nofollow"/>
        <meta name="googlebot" content="noindex">
        <link rel="stylesheet" href="/external/css/uikit/compiler.dev55.20191008.css">
        <link rel="stylesheet" href="/external/css/espace_client/layout.css">
        <script type="text/javascript" src="/admin/?call=getJs&js=jquery/jquery-3.4.1.min.js&t="></script>
        <script type="text/javascript" src="/admin/?call=getJs&js=jquery/jquery-ui.js&t="></script>
        <script type="text/javascript" src="/admin/?call=getJs&js=labs/labs.loader.js&t="></script>
        <script type="text/javascript" src="/admin/?call=getJs&js=widget/slick.min.js&t="></script>
    </head>
            <body>
    <style>
    :root {
        --primary-color: #6db545;
        --primary-color-r: 109;
        --primary-color-g: 181;
        --primary-color-b: 69;
        --primary-color-brightness: ;
        --contrast-color: ;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES TEXTES -*-*-*-*-*-*-*-*-*-*-*- */
    .colorPrimaryPrint_Color {
        color: ;
        fill: ;
        stroke: ;
    }
    .colorPrimary_ColorParentCible span,
    .colorPrimary_Color {
        color: #6db545;
        fill: #6db545;
        stroke: #6db545;
    }

    .colorPrimary_ColorImportant {
        color: #6db545 !important;
        fill: #6db545 !important;
        stroke: #6db545 !important;
    }

    .colorPrimary_ColorHover:hover,
    .colorPrimary_ColorHover:active,
    .colorPrimary_ColorBefore:before,
    .colorPrimary_ColorAfter:after,
    .colorPrimary_ColorHoverBefore:hover:before,
    .colorPrimary_ColorHoverBefore:active:before,
    .colorPrimary_ColorHoverAfter:hover:after,
    .colorPrimary_ColorHoverAfter:active:after,
    .active.colorPrimary_ColorActive,
    .selected.colorPrimary_ColorActive,
    .checked.colorPrimary_ColorActive,
    .active.colorPrimary_ColorActiveBefore:before,
    .selected.colorPrimary_ColorActiveBefore:before,
    .checked.colorPrimary_ColorActiveBefore:before,
    .active.colorPrimary_ColorActiveAfter:after,
    .selected.colorPrimary_ColorActiveAfter:after,
    .checked.colorPrimary_ColorActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantColor,
    .colorPrimary_Parent:hover .colorPrimary_EnfantColorHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantColorChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantColorHover,
    .colorPrimary_Parent .colorPrimary_EnfantColorBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantColorAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantColorHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantColorCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantColorHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantColorHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantColorCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantColorHoverAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantColorActive,
    .selected.colorPrimary_Parent .colorPrimary_EnfantColorActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantColorActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantColorActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantColorActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantColorActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantColorActiveAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantColorActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantColorActiveAfter:after {
        color: #6db545 !important;
        fill: #6db545 !important;
        stroke: #6db545 !important;

    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background {
        background: #6db545;
    }

    .colorPrimary_BackgroundImportant {
        background: #6db545 !important;
    }

    .colorPrimaryPrint_Background {
        background: ;
    }

    .colorPrimaryPrint_BackgroundImportant {
        background:  !important;
    }

    .colorPrimary_BackgroundHover:hover,
    .colorPrimary_BackgroundHover:active,
    .colorPrimary_BackgroundBefore:before,
    .colorPrimary_BackgroundAfter:after,
    .colorPrimary_BackgroundHoverBefore:hover:before,
    .colorPrimary_BackgroundHoverBefore:active:before,
    .colorPrimary_BackgroundHoverAfter:hover:after,
    .colorPrimary_BackgroundHoverAfter:active:after,
    .active.colorPrimary_BackgroundActive,
    .selected.colorPrimary_BackgroundActive,
    .checked.colorPrimary_BackgroundActive,
    .active.colorPrimary_BackgroundActiveBefore:before,
    .selected.colorPrimary_BackgroundActiveBefore:before,
    .checked.colorPrimary_BackgroundActiveBefore:before,
    .active.colorPrimary_BackgroundActiveAfter:after,
    .selected.colorPrimary_BackgroundActiveAfter:after,
    .checked.colorPrimary_BackgroundActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackgroundHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackgroundChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackgroundHover,
    .colorPrimary_Parent .colorPrimary_EnfantBackgroundBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackgroundAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackgroundHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackgroundCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackgroundHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackgroundHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackgroundCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackgroundHoverAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackgroundActive,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackgroundActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackgroundActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackgroundActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackgroundActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackgroundActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackgroundActiveAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackgroundActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackgroundActiveAfter:after {
        background: #6db545 !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 10 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background10 {
        background: rgba(109,181,69,0.1);
    }

    .colorPrimary_Background10Important {
        background: rgba(109,181,69,0.1) !important;
    }

    .colorPrimary_Background10Hover:hover,
    .colorPrimary_Background10Hover:active,
    .colorPrimary_Background10Before:before,
    .colorPrimary_Background10After:after,
    .colorPrimary_Background10HoverBefore:hover:before,
    .colorPrimary_Background10HoverBefore:active:before,
    .colorPrimary_Background10HoverAfter:hover:after,
    .colorPrimary_Background10HoverAfter:active:after,
    .active.colorPrimary_Background10Active,
    .selected.colorPrimary_Background10Active,
    .checked.colorPrimary_Background10Active,
    .active.colorPrimary_Background10ActiveBefore:before,
    .selected.colorPrimary_Background10ActiveBefore:before,
    .checked.colorPrimary_Background10ActiveBefore:before,
    .active.colorPrimary_Background10ActiveAfter:after,
    .selected.colorPrimary_Background10ActiveAfter:after,
    .checked.colorPrimary_Background10ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground10,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground10Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground10Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground10Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground10Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground10After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground10HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground10CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground10HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground10HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground10CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground10HoverAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground10Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground10Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground10Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground10ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground10ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground10ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground10ActiveAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground10ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground10ActiveAfter:after {
        background: rgba(109,181,69,0.1) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 20 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background20 {
        background: rgba(109,181,69,0.2);
    }

    .colorPrimary_Background20Important {
        background: rgba(109,181,69,0.2) !important;
    }

    .colorPrimary_Background20Hover:hover,
    .colorPrimary_Background20Hover:active,
    .colorPrimary_Background20Before:before,
    .colorPrimary_Background20After:after,
    .colorPrimary_Background20BeforeHover:hover:before,
    .colorPrimary_Background20BeforeHover:active:before,
    .colorPrimary_Background20AfterHover:hover:after,
    .colorPrimary_Background20AfterHover:active:after,
    .selected.colorPrimary_Background20Active,
    .active.colorPrimary_Background20Active,
    .checked.colorPrimary_Background20Active,
    .selected.colorPrimary_Background20ActiveBefore:before,
    .active.colorPrimary_Background20ActiveBefore:before,
    .checked.colorPrimary_Background20ActiveBefore:before,
    .selected.colorPrimary_Background20ActiveAfter:after,
    .active.colorPrimary_Background20ActiveAfter:after,
    .checked.colorPrimary_Background20ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground20,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground20Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground20Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground20Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground20Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground20After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground20HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground20CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground20HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground20HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground20CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground20HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground20Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground20Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground20Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground20ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground20ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground20ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground20ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground20ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground20ActiveAfter:after {
        background: rgba(109,181,69,0.2) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 30 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background30 {
        background: rgba(109,181,69,0.3);
    }

    .colorPrimary_Background30Important {
        background: rgba(109,181,69,0.3) !important;
    }

    .colorPrimary_Background30Hover:hover,
    .colorPrimary_Background30Hover:active,
    .colorPrimary_Background30Before:before,
    .colorPrimary_Background30After:after,
    .colorPrimary_Background30HoverBefore:hover:before,
    .colorPrimary_Background30HoverBefore:active:before,
    .colorPrimary_Background30HoverAfter:hover:after,
    .colorPrimary_Background30HoverAfter:active:after,
    .selected.colorPrimary_Background30Active,
    .active.colorPrimary_Background30Active,
    .checked.colorPrimary_Background30Active,
    .selected.colorPrimary_Background30ActiveBefore:before,
    .active.colorPrimary_Background30ActiveBefore:before,
    .checked.colorPrimary_Background30ActiveBefore:before,
    .selected.colorPrimary_Background30ActiveAfter:after,
    .active.colorPrimary_Background30ActiveAfter:after,
    .checked.colorPrimary_Background30ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground30,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground30Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground30Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground30Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground30Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground30After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground30HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground30CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground30HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground30HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground30CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground30HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground30Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground30Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground30Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground30ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground30ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground30ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground30ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground30ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground30ActiveAfter:after {
        background: rgba(109,181,69,0.3) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 40 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background40 {
        background: rgba(109,181,69,0.4);
    }

    .colorPrimary_Background40Important {
        background: rgba(109,181,69,0.4) !important;
    }

    .colorPrimary_Background40Hover:hover,
    .colorPrimary_Background40Hover:active,
    .colorPrimary_Background40Before:before,
    .colorPrimary_Background40After:after,
    .colorPrimary_Background40HoverBefore:hover:before,
    .colorPrimary_Background40HoverBefore:active:before,
    .colorPrimary_Background40HoverAfter:hover:after,
    .colorPrimary_Background40HoverAfter:active:after,
    .selected.colorPrimary_Background40Active,
    .active.colorPrimary_Background40Active,
    .checked.colorPrimary_Background40Active,
    .selected.colorPrimary_Background40ActiveBefore:before,
    .active.colorPrimary_Background40ActiveBefore:before,
    .checked.colorPrimary_Background40ActiveBefore:before,
    .selected.colorPrimary_Background40ActiveAfter:after,
    .active.colorPrimary_Background40ActiveAfter:after,
    .checked.colorPrimary_Background40ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground40,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground40Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground40Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground40Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground40Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground40After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground40HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground40CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground40HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground40HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground40CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground40HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground40Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground40Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground40Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground40ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground40ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground40ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground40ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground40ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground40ActiveAfter:after {
        background: rgba(109,181,69,0.4) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 50 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background50 {
        background: rgba(109,181,69,0.5);
    }

    .colorPrimary_Background50Important {
        background: rgba(109,181,69,0.5) !important;
    }

    .colorPrimary_Background50Hover:hover,
    .colorPrimary_Background50Hover:active,
    .colorPrimary_Background50Before:before,
    .colorPrimary_Background50After:after,
    .colorPrimary_Background50HoverBefore:hover:before,
    .colorPrimary_Background50HoverBefore:active:before,
    .colorPrimary_Background50HoverAfter:hover:after,
    .colorPrimary_Background50HoverAfter:active:after,
    .selected.colorPrimary_Background50Active,
    .active.colorPrimary_Background50Active,
    .checked.colorPrimary_Background50Active,
    .selected.colorPrimary_Background50ActiveBefore:before,
    .active.colorPrimary_Background50ActiveBefore:before,
    .checked.colorPrimary_Background50ActiveBefore:before,
    .selected.colorPrimary_Background50ActiveAfter:after,
    .active.colorPrimary_Background50ActiveAfter:after,
    .checked.colorPrimary_Background50ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground50,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground50Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground50Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground50Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground50Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground50After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground50HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground50CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground50HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground50HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground50CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground50HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground50Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground50Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground50Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground50ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground50ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground50ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground50ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground50ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground50ActiveAfter:after {
        background: rgba(109,181,69,0.5) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 60 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background60 {
        background: rgba(109,181,69,0.6);
    }

    .colorPrimary_Background60Important {
        background: rgba(109,181,69,0.6) !important;
    }

    .colorPrimary_Background60Hover:hover,
    .colorPrimary_Background60Hover:active,
    .colorPrimary_Background60Before:before,
    .colorPrimary_Background60After:after,
    .colorPrimary_Background60HoverBefore:hover:before,
    .colorPrimary_Background60HoverBefore:active:before,
    .colorPrimary_Background60HoverAfter:hover:after,
    .colorPrimary_Background60HoverAfter:active:after,
    .selected.colorPrimary_Background60Active,
    .active.colorPrimary_Background60Active,
    .checked.colorPrimary_Background60Active,
    .selected.colorPrimary_Background60ActiveBefore:before,
    .active.colorPrimary_Background60ActiveBefore:before,
    .checked.colorPrimary_Background60ActiveBefore:before,
    .selected.colorPrimary_Background60ActiveAfter:after,
    .active.colorPrimary_Background60ActiveAfter:after,
    .checked.colorPrimary_Background60ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground60,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground60Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground60Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground60Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground60Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground60After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground60HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground60CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground60HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground60HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground60CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground60HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground60Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground60Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground60Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground60ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground60ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground60ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground60ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground60ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground60ActiveAfter:after {
        background: rgba(109,181,69,0.6) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 70 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background70 {
        background: rgba(109,181,69,0.7);
    }

    .colorPrimary_Background70Important {
        background: rgba(109,181,69,0.7) !important;
    }

    .colorPrimary_Background70Hover:hover,
    .colorPrimary_Background70Hover:active,
    .colorPrimary_Background70Before:before,
    .colorPrimary_Background70After:after,
    .colorPrimary_Background70HoverBefore:hover:before,
    .colorPrimary_Background70HoverBefore:active:before,
    .colorPrimary_Background70HoverAfter:hover:after,
    .colorPrimary_Background70HoverAfter:active:after,
    .selected.colorPrimary_Background70Active,
    .active.colorPrimary_Background70Active,
    .checked.colorPrimary_Background70Active,
    .selected.colorPrimary_Background70ActiveBefore:before,
    .active.colorPrimary_Background70ActiveBefore:before,
    .checked.colorPrimary_Background70ActiveBefore:before,
    .selected.colorPrimary_Background70ActiveAfter:after,
    .active.colorPrimary_Background70ActiveAfter:after,
    .checked.colorPrimary_Background70ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground70,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground70Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground70Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground70Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground70Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground70After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground70HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground70CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground70HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground70HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground70CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground70HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground70Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground70Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground70Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground70ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground70ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground70ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground70ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground70ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground70ActiveAfter:after {
        background: rgba(109,181,69,0.7) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 80 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background80 {
        background: rgba(109,181,69,0.8);
    }

    .colorPrimary_Background80Important {
        background: rgba(109,181,69,0.8) !important;
    }

    .colorPrimary_Background80Hover:hover,
    .colorPrimary_Background80Hover:active,
    .colorPrimary_Background80Before:before,
    .colorPrimary_Background80After:after,
    .colorPrimary_Background80HoverBefore:hover:before,
    .colorPrimary_Background80HoverBefore:active:before,
    .colorPrimary_Background80HoverAfter:hover:after,
    .colorPrimary_Background80HoverAfter:active:after,
    .selected.colorPrimary_Background80Active,
    .active.colorPrimary_Background80Active,
    .checked.colorPrimary_Background80Active,
    .selected.colorPrimary_Background80ActiveBefore:before,
    .active.colorPrimary_Background80ActiveBefore:before,
    .checked.colorPrimary_Background80ActiveBefore:before,
    .selected.colorPrimary_Background80ActiveAfter:after,
    .active.colorPrimary_Background80ActiveAfter:after,
    .checked.colorPrimary_Background80ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground80,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground80Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground80Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground80Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground80Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground80After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground80HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground80CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground80HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground80HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground80CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground80HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground80Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground80Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground80Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground80ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground80ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground80ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground80ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground80ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground80ActiveAfter:after {
        background: rgba(109,181,69,0.8) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BACKGROUND OPACITE 90 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Background90 {
        background: rgba(109,181,69,0.9);
    }

    .colorPrimary_Background90Important {
        background: rgba(109,181,69,0.9) !important;
    }

    .colorPrimary_Background90Hover:hover,
    .colorPrimary_Background90Hover:active,
    .colorPrimary_Background90Before:before,
    .colorPrimary_Background90After:after,
    .colorPrimary_Background90HoverBefore:hover:before,
    .colorPrimary_Background90HoverBefore:active:before,
    .colorPrimary_Background90HoverAfter:hover:after,
    .colorPrimary_Background90HoverAfter:active:after,
    .selected.colorPrimary_Background90Active,
    .active.colorPrimary_Background90Active,
    .checked.colorPrimary_Background90Active,
    .selected.colorPrimary_Background90ActiveBefore:before,
    .active.colorPrimary_Background90ActiveBefore:before,
    .checked.colorPrimary_Background90ActiveBefore:before,
    .selected.colorPrimary_Background90ActiveAfter:after,
    .active.colorPrimary_Background90ActiveAfter:after,
    .checked.colorPrimary_Background90ActiveAfter:after,
    .colorPrimary_Parent .colorPrimary_EnfantBackground90,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground90Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground90Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground90Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBackground90Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBackground90After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground90HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground90CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground90HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBackground90HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBackground90CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBackground90HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground90Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground90Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground90Active,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground90ActiveBefore:before,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground90ActiveBefore:before,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground90ActiveBefore:before,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBackground90ActiveAfter:after,
    .active.colorPrimary_Parent .colorPrimary_EnfantBackground90ActiveAfter:after,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBackground90ActiveAfter:after {
        background: rgba(109,181,69,0.9) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border {
        border-color: #6db545;
    }

    .colorPrimary_BorderImportant {
        border-color: #6db545 !important;
    }

    .colorPrimary_BorderHover:hover,
    .colorPrimary_BorderHover:active,
    .colorPrimary_BorderBefore:before,
    .colorPrimary_BorderAfter:after,
    .colorPrimary_BorderHoverBefore:hover:before,
    .colorPrimary_BorderHoverBefore:active:before,
    .colorPrimary_BorderHoverAfter:hover:after,
    .colorPrimary_BorderHoverAfter:active:after,
    .selected.colorPrimary_BorderActive,
    .active.colorPrimary_BorderActive,
    .checked.colorPrimary_BorderActive,
    .colorPrimary_Parent .colorPrimary_EnfantBorder,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorderBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorderAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorderActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorderActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorderActive {
        border-color: #6db545 !important;
    }

    .colorPrimary_BorderBottom {
        border-bottom-color: #6db545;
    }

    .colorPrimary_BorderBottomImportant {
        border-bottom-color: #6db545 !important;
    }

    .colorPrimary_BorderBottomHover:hover,
    .colorPrimary_BorderBottomHover:active,
    .colorPrimary_BorderBottomBefore:before,
    .colorPrimary_BorderBottomAfter:after,
    .colorPrimary_BorderBottomHoverBefore:hover:before,
    .colorPrimary_BorderBottomHoverBefore:active:before,
    .colorPrimary_BorderBottomHoverAfter:hover:after,
    .colorPrimary_BorderBottomHoverAfter:active:after,
    .colorPrimary_Parent .colorPrimary_EnfantBorderBottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderBottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderBottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderBottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorderBottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorderBottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderBottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderBottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderBottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderBottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderBottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderBottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorderBottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorderBottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorderBottomActive {
        border-bottom-color: #6db545 !important;
    }

    .colorPrimary_BorderTop {
        border-top-color: #6db545;
    }

    .colorPrimary_BorderTopImportant {
        border-top-color: #6db545 !important;
    }

    .colorPrimary_BorderTopHover:hover,
    .colorPrimary_BorderTopHover:active,
    .colorPrimary_BorderTopBefore:before,
    .colorPrimary_BorderTopAfter:after,
    .colorPrimary_BorderTopHoverBefore:hover:before,
    .colorPrimary_BorderTopHoverBefore:active:before,
    .colorPrimary_BorderTopHoverAfter:hover:after,
    .colorPrimary_BorderTopHoverAfter:active:after,
    .colorPrimary_Parent .colorPrimary_EnfantBorderTop,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderTopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderTopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderTopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorderTopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorderTopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderTopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderTopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderTopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderTopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderTopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderTopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorderTopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorderTopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorderTopActive {
        border-top-color: #6db545 !important;
    }

    .colorPrimary_BorderRightImportant {
        border-right-color: #6db545 !important;
    }

    .colorPrimary_BorderRightImportant,
    .colorPrimary_BorderRightHover:hover,
    .colorPrimary_BorderRightHover:active,
    .colorPrimary_BorderRightBefore:before,
    .colorPrimary_BorderRightAfter:after,
    .colorPrimary_BorderRightHoverBefore:hover:before,
    .colorPrimary_BorderRightHoverBefore:active:before,
    .colorPrimary_BorderRightHoverAfter:hover:after,
    .colorPrimary_BorderRightHoverAfter:active:after,
    .colorPrimary_Parent .colorPrimary_EnfantBorderRight,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderRightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderRightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderRightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorderRightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorderRightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderRightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderRightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderRightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderRightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderRightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderRightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorderRightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorderRightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorderRightActive {
        border-right-color: #6db545 !important;
    }

    .colorPrimary_BorderLeft {
        border-left-color: #6db545;
    }

    .colorPrimary_BorderLeftImportant {
        border-left-color: #6db545 !important;
    }

    .colorPrimary_BorderLeftHover:hover,
    .colorPrimary_BorderLeftHover:active,
    .colorPrimary_BorderLeftBefore:before,
    .colorPrimary_BorderLeftAfter:after,
    .colorPrimary_BorderLeftHoverBefore:hover:before,
    .colorPrimary_BorderLeftHoverBefore:active:before,
    .colorPrimary_BorderLeftHoverAfter:hover:after,
    .colorPrimary_BorderLeftHoverAfter:active:after,
    .colorPrimary_Parent .colorPrimary_EnfantBorderLeft,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderLeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderLeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderLeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorderLeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorderLeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderLeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderLeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderLeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorderLeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorderLeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorderLeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorderLeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorderLeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorderLeftActive {
        border-left-color: #6db545 !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 10 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border10,
    .colorPrimary_Border10Hover:hover,
    .colorPrimary_Border10Hover:active,
    .colorPrimary_Border10Before:before,
    .colorPrimary_Border10After:after,
    .colorPrimary_Border10HoverBefore:hover:before,
    .colorPrimary_Border10HoverBefore:active:before,
    .colorPrimary_Border10HoverAfter:hover:after,
    .colorPrimary_Border10HoverAfter:active:after {
        border-color: rgba(109,181,69,0.1);

    }

    .selected.colorPrimary_Border10Active,
    .active.colorPrimary_Border10Active,
    .checked.colorPrimary_Border10Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder10Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder10Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder10Active {
        border-color: rgba(109,181,69,0.1) !important;
    }

    .colorPrimary_Border10Bottom,
    .colorPrimary_Border10BottomHover:hover,
    .colorPrimary_Border10BottomHover:active,
    .colorPrimary_Border10BottomBefore:before,
    .colorPrimary_Border10BottomAfter:after,
    .colorPrimary_Border10BottomHoverBefore:hover:before,
    .colorPrimary_Border10BottomHoverBefore:active:before,
    .colorPrimary_Border10BottomHoverAfter:hover:after,
    .colorPrimary_Border10BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.1);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder10Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder10BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder10BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder10BottomActive {
        border-bottom-color: rgba(109,181,69,0.1) !important;
    }

    .colorPrimary_Border10Top,
    .colorPrimary_Border10TopHover:hover,
    .colorPrimary_Border10TopHover:active,
    .colorPrimary_Border10TopBefore:before,
    .colorPrimary_Border10TopAfter:after,
    .colorPrimary_Border10TopHoverBefore:hover:before,
    .colorPrimary_Border10TopHoverBefore:active:before,
    .colorPrimary_Border10TopHoverAfter:hover:after,
    .colorPrimary_Border10TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.1);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder10Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder10TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder10TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder10TopActive {
        border-top-color: rgba(109,181,69,0.1) !important;
    }

    .colorPrimary_Border10Right,
    .colorPrimary_Border10RightHover:hover,
    .colorPrimary_Border10RightHover:active,
    .colorPrimary_Border10RightBefore:before,
    .colorPrimary_Border10RightAfter:after,
    .colorPrimary_Border10RightHoverBefore:hover:before,
    .colorPrimary_Border10RightHoverBefore:active:before,
    .colorPrimary_Border10RightHoverAfter:hover:after,
    .colorPrimary_Border10RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.1);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder10Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder10RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder10RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder10RightActive {
        border-right-color: rgba(109,181,69,0.1) !important;
    }

    .colorPrimary_Border10Left,
    .colorPrimary_Border10LeftHover:hover,
    .colorPrimary_Border10LeftHover:active,
    .colorPrimary_Border10LeftBefore:before,
    .colorPrimary_Border10LeftAfter:after,
    .colorPrimary_Border10LeftHoverBefore:hover:before,
    .colorPrimary_Border10LeftHoverBefore:active:before,
    .colorPrimary_Border10LeftHoverAfter:hover:after,
    .colorPrimary_Border10LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.1);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder10Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder10LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder10LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder10LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder10LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder10LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder10LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder10LeftActive {
        border-left-color: rgba(109,181,69,0.1) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 20 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border20,
    .colorPrimary_Border20Hover:hover,
    .colorPrimary_Border20Hover:active,
    .colorPrimary_Border20Before:before,
    .colorPrimary_Border20After:after,
    .colorPrimary_Border20HoverBefore:hover:before,
    .colorPrimary_Border20HoverBefore:active:before,
    .colorPrimary_Border20HoverAfter:hover:after,
    .colorPrimary_Border20HoverAfter:active:after {
        border-color: rgba(109,181,69,0.2);
    }

    .selected.colorPrimary_Border20Active,
    .active.colorPrimary_Border20Active,
    .checked.colorPrimary_Border20Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder20Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder20Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder20Active {
        border-color: rgba(109,181,69,0.2) !important;
    }

    .colorPrimary_Border20Bottom,
    .colorPrimary_Border20BottomHover:hover,
    .colorPrimary_Border20BottomHover:active,
    .colorPrimary_Border20BottomBefore:before,
    .colorPrimary_Border20BottomAfter:after,
    .colorPrimary_Border20BottomHoverBefore:hover:before,
    .colorPrimary_Border20BottomHoverBefore:active:before,
    .colorPrimary_Border20BottomHoverAfter:hover:after,
    .colorPrimary_Border20BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.2);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder20Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder20BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder20BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder20BottomActive {
        border-bottom-color: rgba(109,181,69,0.2) !important;
    }

    .colorPrimary_Border20Top,
    .colorPrimary_Border20TopHover:hover,
    .colorPrimary_Border20TopHover:active,
    .colorPrimary_Border20TopBefore:before,
    .colorPrimary_Border20TopAfter:after,
    .colorPrimary_Border20TopHoverBefore:hover:before,
    .colorPrimary_Border20TopHoverBefore:active:before,
    .colorPrimary_Border20TopHoverAfter:hover:after,
    .colorPrimary_Border20TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.2);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder20Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder20TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder20TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder20TopActive {
        border-top-color: rgba(109,181,69,0.2) !important;
    }

    .colorPrimary_Border20Right,
    .colorPrimary_Border20RightHover:hover,
    .colorPrimary_Border20RightHover:active,
    .colorPrimary_Border20RightBefore:before,
    .colorPrimary_Border20RightAfter:after,
    .colorPrimary_Border20RightHoverBefore:hover:before,
    .colorPrimary_Border20RightHoverBefore:active:before,
    .colorPrimary_Border20RightHoverAfter:hover:after,
    .colorPrimary_Border20RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.2);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder20Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder20RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder20RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder20RightActive {
        border-right-color: rgba(109,181,69,0.2) !important;
    }

    .colorPrimary_Border20Left,
    .colorPrimary_Border20LeftHover:hover,
    .colorPrimary_Border20LeftHover:active,
    .colorPrimary_Border20LeftBefore:before,
    .colorPrimary_Border20LeftAfter:after,
    .colorPrimary_Border20LeftHoverBefore:hover:before,
    .colorPrimary_Border20LeftHoverBefore:active:before,
    .colorPrimary_Border20LeftHoverAfter:hover:after,
    .colorPrimary_Border20LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.2);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder20Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder20LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder20LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder20LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder20LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder20LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder20LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder20LeftActive {
        border-left-color: rgba(109,181,69,0.2) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 30 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border30,
    .colorPrimary_Border30Hover:hover,
    .colorPrimary_Border30Hover:active,
    .colorPrimary_Border30Before:before,
    .colorPrimary_Border30After:after,
    .colorPrimary_Border30HoverBefore:hover:before,
    .colorPrimary_Border30HoverBefore:active:before,
    .colorPrimary_Border30HoverAfter:hover:after,
    .colorPrimary_Border30HoverAfter:active:after {
        border-color: rgba(109,181,69,0.3);
    }

    .selected.colorPrimary_Border30Active,
    .active.colorPrimary_Border30Active,
    .checked.colorPrimary_Border30Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder30Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder30Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder30Active {
        border-color: rgba(109,181,69,0.3) !important;
    }

    .colorPrimary_Border30Bottom,
    .colorPrimary_Border30BottomHover:hover,
    .colorPrimary_Border30BottomHover:active,
    .colorPrimary_Border30BottomBefore:before,
    .colorPrimary_Border30BottomAfter:after,
    .colorPrimary_Border30BottomHoverBefore:hover:before,
    .colorPrimary_Border30BottomHoverBefore:active:before,
    .colorPrimary_Border30BottomHoverAfter:hover:after,
    .colorPrimary_Border30BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.3);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder30Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder30BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder30BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder30BottomActive {
        border-bottom-color: rgba(109,181,69,0.3) !important;
    }

    .colorPrimary_Border30Top,
    .colorPrimary_Border30TopHover:hover,
    .colorPrimary_Border30TopHover:active,
    .colorPrimary_Border30TopBefore:before,
    .colorPrimary_Border30TopAfter:after,
    .colorPrimary_Border30TopHoverBefore:hover:before,
    .colorPrimary_Border30TopHoverBefore:active:before,
    .colorPrimary_Border30TopHoverAfter:hover:after,
    .colorPrimary_Border30TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.3);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder30Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder30TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder30TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder30TopActive {
        border-top-color: rgba(109,181,69,0.3) !important;
    }

    .colorPrimary_Border30Right,
    .colorPrimary_Border30RightHover:hover,
    .colorPrimary_Border30RightHover:active,
    .colorPrimary_Border30RightBefore:before,
    .colorPrimary_Border30RightAfter:after,
    .colorPrimary_Border30RightHoverBefore:hover:before,
    .colorPrimary_Border30RightHoverBefore:active:before,
    .colorPrimary_Border30RightHoverAfter:hover:after,
    .colorPrimary_Border30RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.3);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder30Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder30RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder30RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder30RightActive {
        border-right-color: rgba(109,181,69,0.3) !important;
    }

    .colorPrimary_Border30Left,
    .colorPrimary_Border30LeftHover:hover,
    .colorPrimary_Border30LeftHover:active,
    .colorPrimary_Border30LeftBefore:before,
    .colorPrimary_Border30LeftAfter:after,
    .colorPrimary_Border30LeftHoverBefore:hover:before,
    .colorPrimary_Border30LeftHoverBefore:active:before,
    .colorPrimary_Border30LeftHoverAfter:hover:after,
    .colorPrimary_Border30LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.3);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder30Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder30LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder30LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder30LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder30LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder30LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder30LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder30LeftActive {
        border-left-color: rgba(109,181,69,0.3) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 40 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border40,
    .colorPrimary_Border40Hover:hover,
    .colorPrimary_Border40Hover:active,
    .colorPrimary_Border40Before:before,
    .colorPrimary_Border40After:after,
    .colorPrimary_Border40HoverBefore:hover:before,
    .colorPrimary_Border40HoverBefore:active:before,
    .colorPrimary_Border40HoverAfter:hover:after,
    .colorPrimary_Border40HoverAfter:active:after {
        border-color: rgba(109,181,69,0.4);
    }

    .selected.colorPrimary_Border40Active,
    .active.colorPrimary_Border40Active,
    .checked.colorPrimary_Border40Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder40Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder40Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder40Active {
        border-color: rgba(109,181,69,0.4) !important;
    }

    .colorPrimary_Border40Bottom,
    .colorPrimary_Border40BottomHover:hover,
    .colorPrimary_Border40BottomHover:active,
    .colorPrimary_Border40BottomBefore:before,
    .colorPrimary_Border40BottomAfter:after,
    .colorPrimary_Border40BottomHoverBefore:hover:before,
    .colorPrimary_Border40BottomHoverBefore:active:before,
    .colorPrimary_Border40BottomHoverAfter:hover:after,
    .colorPrimary_Border40BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.4);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder40Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder40BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder40BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder40BottomActive {
        border-bottom-color: rgba(109,181,69,0.4) !important;
    }

    .colorPrimary_Border40Top,
    .colorPrimary_Border40TopHover:hover,
    .colorPrimary_Border40TopHover:active,
    .colorPrimary_Border40TopBefore:before,
    .colorPrimary_Border40TopAfter:after,
    .colorPrimary_Border40TopHoverBefore:hover:before,
    .colorPrimary_Border40TopHoverBefore:active:before,
    .colorPrimary_Border40TopHoverAfter:hover:after,
    .colorPrimary_Border40TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.4);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder40Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder40TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder40TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder40TopActive {
        border-top-color: rgba(109,181,69,0.4) !important;
    }

    .colorPrimary_Border40Right,
    .colorPrimary_Border40RightHover:hover,
    .colorPrimary_Border40RightHover:active,
    .colorPrimary_Border40RightBefore:before,
    .colorPrimary_Border40RightAfter:after,
    .colorPrimary_Border40RightHoverBefore:hover:before,
    .colorPrimary_Border40RightHoverBefore:active:before,
    .colorPrimary_Border40RightHoverAfter:hover:after,
    .colorPrimary_Border40RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.4);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder40Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder40RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder40RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder40RightActive {
        border-right-color: rgba(109,181,69,0.4) !important;
    }

    .colorPrimary_Border40Left,
    .colorPrimary_Border40LeftHover:hover,
    .colorPrimary_Border40LeftHover:active,
    .colorPrimary_Border40LeftBefore:before,
    .colorPrimary_Border40LeftAfter:after,
    .colorPrimary_Border40LeftHoverBefore:hover:before,
    .colorPrimary_Border40LeftHoverBefore:active:before,
    .colorPrimary_Border40LeftHoverAfter:hover:after,
    .colorPrimary_Border40LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.4);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder40Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder40LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder40LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder40LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder40LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder40LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder40LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder40LeftActive {
        border-left-color: rgba(109,181,69,0.4) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 50 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border50,
    .colorPrimary_Border50Hover:hover,
    .colorPrimary_Border50Hover:active,
    .colorPrimary_Border50Before:before,
    .colorPrimary_Border50After:after,
    .colorPrimary_Border50HoverBefore:hover:before,
    .colorPrimary_Border50HoverBefore:active:before,
    .colorPrimary_Border50HoverAfter:hover:after,
    .colorPrimary_Border50HoverAfter:active:after {
        border-color: rgba(109,181,69,0.5);
    }

    .selected.colorPrimary_Border50Active,
    .active.colorPrimary_Border50Active,
    .checked.colorPrimary_Border50Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder50Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder50Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder50Active {
        border-color: rgba(109,181,69,0.5) !important;
    }

    .colorPrimary_Border50Bottom,
    .colorPrimary_Border50BottomHover:hover,
    .colorPrimary_Border50BottomHover:active,
    .colorPrimary_Border50BottomBefore:before,
    .colorPrimary_Border50BottomAfter:after,
    .colorPrimary_Border50BottomHoverBefore:hover:before,
    .colorPrimary_Border50BottomHoverBefore:active:before,
    .colorPrimary_Border50BottomHoverAfter:hover:after,
    .colorPrimary_Border50BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.5);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder50Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder50BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder50BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder50BottomActive {
        border-bottom-color: rgba(109,181,69,0.5) !important;
    }

    .colorPrimary_Border50Top,
    .colorPrimary_Border50TopHover:hover,
    .colorPrimary_Border50TopHover:active,
    .colorPrimary_Border50TopBefore:before,
    .colorPrimary_Border50TopAfter:after,
    .colorPrimary_Border50TopHoverBefore:hover:before,
    .colorPrimary_Border50TopHoverBefore:active:before,
    .colorPrimary_Border50TopHoverAfter:hover:after,
    .colorPrimary_Border50TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.5);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder50Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder50TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder50TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder50TopActive {
        border-top-color: rgba(109,181,69,0.5) !important;
    }

    .colorPrimary_Border50Right,
    .colorPrimary_Border50RightHover:hover,
    .colorPrimary_Border50RightHover:active,
    .colorPrimary_Border50RightBefore:before,
    .colorPrimary_Border50RightAfter:after,
    .colorPrimary_Border50RightHoverBefore:hover:before,
    .colorPrimary_Border50RightHoverBefore:active:before,
    .colorPrimary_Border50RightHoverAfter:hover:after,
    .colorPrimary_Border50RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.5);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder50Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder50RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder50RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder50RightActive {
        border-right-color: rgba(109,181,69,0.5) !important;
    }

    .colorPrimary_Border50Left,
    .colorPrimary_Border50LeftHover:hover,
    .colorPrimary_Border50LeftHover:active,
    .colorPrimary_Border50LeftBefore:before,
    .colorPrimary_Border50LeftAfter:after,
    .colorPrimary_Border50LeftHoverBefore:hover:before,
    .colorPrimary_Border50LeftHoverBefore:active:before,
    .colorPrimary_Border50LeftHoverAfter:hover:after,
    .colorPrimary_Border50LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.5);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder50Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder50LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder50LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder50LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder50LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder50LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder50LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder50LeftActive {
        border-left-color: rgba(109,181,69,0.5) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 60 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border60,
    .colorPrimary_Border60Hover:hover,
    .colorPrimary_Border60Hover:active,
    .colorPrimary_Border60Before:before,
    .colorPrimary_Border60After:after,
    .colorPrimary_Border60HoverBefore:hover:before,
    .colorPrimary_Border60HoverBefore:active:before,
    .colorPrimary_Border60HoverAfter:hover:after,
    .colorPrimary_Border60HoverAfter:active:after {
        border-color: rgba(109,181,69,0.6);
    }

    .selected.colorPrimary_Border60Active,
    .active.colorPrimary_Border60Active,
    .checked.colorPrimary_Border60Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder60Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder60Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder60Active {
        border-color: rgba(109,181,69,0.6) !important;
    }

    .colorPrimary_Border60Bottom,
    .colorPrimary_Border60BottomHover:hover,
    .colorPrimary_Border60BottomHover:active,
    .colorPrimary_Border60BottomBefore:before,
    .colorPrimary_Border60BottomAfter:after,
    .colorPrimary_Border60BottomHoverBefore:hover:before,
    .colorPrimary_Border60BottomHoverBefore:active:before,
    .colorPrimary_Border60BottomHoverAfter:hover:after,
    .colorPrimary_Border60BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.6);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder60Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder60BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder60BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder60BottomActive {
        border-bottom-color: rgba(109,181,69,0.6) !important;
    }

    .colorPrimary_Border60Top,
    .colorPrimary_Border60TopHover:hover,
    .colorPrimary_Border60TopHover:active,
    .colorPrimary_Border60TopBefore:before,
    .colorPrimary_Border60TopAfter:after,
    .colorPrimary_Border60TopHoverBefore:hover:before,
    .colorPrimary_Border60TopHoverBefore:active:before,
    .colorPrimary_Border60TopHoverAfter:hover:after,
    .colorPrimary_Border60TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.6);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder60Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder60TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder60TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder60TopActive {
        border-top-color: rgba(109,181,69,0.6) !important;
    }

    .colorPrimary_Border60Right,
    .colorPrimary_Border60RightHover:hover,
    .colorPrimary_Border60RightHover:active,
    .colorPrimary_Border60RightBefore:before,
    .colorPrimary_Border60RightAfter:after,
    .colorPrimary_Border60RightHoverBefore:hover:before,
    .colorPrimary_Border60RightHoverBefore:active:before,
    .colorPrimary_Border60RightHoverAfter:hover:after,
    .colorPrimary_Border60RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.6);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder60Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder60RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder60RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder60RightActive {
        border-right-color: rgba(109,181,69,0.6) !important;
    }

    .colorPrimary_Border60Left,
    .colorPrimary_Border60LeftHover:hover,
    .colorPrimary_Border60LeftHover:active,
    .colorPrimary_Border60LeftBefore:before,
    .colorPrimary_Border60LeftAfter:after,
    .colorPrimary_Border60LeftHoverBefore:hover:before,
    .colorPrimary_Border60LeftHoverBefore:active:before,
    .colorPrimary_Border60LeftHoverAfter:hover:after,
    .colorPrimary_Border60LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.6);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder60Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder60LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder60LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder60LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder60LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder60LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder60LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder60LeftActive {
        border-left-color: rgba(109,181,69,0.6) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 70 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border70,
    .colorPrimary_Border70Hover:hover,
    .colorPrimary_Border70Hover:active,
    .colorPrimary_Border70Before:before,
    .colorPrimary_Border70After:after,
    .colorPrimary_Border70HoverBefore:hover:before,
    .colorPrimary_Border70HoverBefore:active:before,
    .colorPrimary_Border70HoverAfter:hover:after,
    .colorPrimary_Border70HoverAfter:active:after {
        border-color: rgba(109,181,69,0.7);
    }

    .selected.colorPrimary_Border70Active,
    .active.colorPrimary_Border70Active,
    .checked.colorPrimary_Border70Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder70Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder70Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder70Active {
        border-color: rgba(109,181,69,0.7) !important;
    }

    .colorPrimary_Border70Bottom,
    .colorPrimary_Border70BottomHover:hover,
    .colorPrimary_Border70BottomHover:active,
    .colorPrimary_Border70BottomBefore:before,
    .colorPrimary_Border70BottomAfter:after,
    .colorPrimary_Border70BottomHoverBefore:hover:before,
    .colorPrimary_Border70BottomHoverBefore:active:before,
    .colorPrimary_Border70BottomHoverAfter:hover:after,
    .colorPrimary_Border70BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.7);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder70Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder70BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder70BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder70BottomActive {
        border-bottom-color: rgba(109,181,69,0.7) !important;
    }

    .colorPrimary_Border70Top,
    .colorPrimary_Border70TopHover:hover,
    .colorPrimary_Border70TopHover:active,
    .colorPrimary_Border70TopBefore:before,
    .colorPrimary_Border70TopAfter:after,
    .colorPrimary_Border70TopHoverBefore:hover:before,
    .colorPrimary_Border70TopHoverBefore:active:before,
    .colorPrimary_Border70TopHoverAfter:hover:after,
    .colorPrimary_Border70TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.7);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder70Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder70TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder70TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder70TopActive {
        border-top-color: rgba(109,181,69,0.7) !important;
    }

    .colorPrimary_Border70Right,
    .colorPrimary_Border70RightHover:hover,
    .colorPrimary_Border70RightHover:active,
    .colorPrimary_Border70RightBefore:before,
    .colorPrimary_Border70RightAfter:after,
    .colorPrimary_Border70RightHoverBefore:hover:before,
    .colorPrimary_Border70RightHoverBefore:active:before,
    .colorPrimary_Border70RightHoverAfter:hover:after,
    .colorPrimary_Border70RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.7);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder70Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder70RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder70RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder70RightActive {
        border-right-color: rgba(109,181,69,0.7) !important;
    }

    .colorPrimary_Border70Left,
    .colorPrimary_Border70LeftHover:hover,
    .colorPrimary_Border70LeftHover:active,
    .colorPrimary_Border70LeftBefore:before,
    .colorPrimary_Border70LeftAfter:after,
    .colorPrimary_Border70LeftHoverBefore:hover:before,
    .colorPrimary_Border70LeftHoverBefore:active:before,
    .colorPrimary_Border70LeftHoverAfter:hover:after,
    .colorPrimary_Border70LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.7);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder70Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder70LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder70LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder70LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder70LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder70LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder70LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder70LeftActive {
        border-left-color: rgba(109,181,69,0.7) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 80 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border80,
    .colorPrimary_Border80Hover:hover,
    .colorPrimary_Border80Hover:active,
    .colorPrimary_Border80Before:before,
    .colorPrimary_Border80After:after,
    .colorPrimary_Border80HoverBefore:hover:before,
    .colorPrimary_Border80HoverBefore:active:before,
    .colorPrimary_Border80HoverAfter:hover:after,
    .colorPrimary_Border80HoverAfter:active:after {
        border-color: rgba(109,181,69,0.8);
    }

    .selected.colorPrimary_Border80Active,
    .active.colorPrimary_Border80Active,
    .checked.colorPrimary_Border80Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder80Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder80Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder80Active {
        border-color: rgba(109,181,69,0.8) !important;
    }

    .colorPrimary_Border80Bottom,
    .colorPrimary_Border80BottomHover:hover,
    .colorPrimary_Border80BottomHover:active,
    .colorPrimary_Border80BottomBefore:before,
    .colorPrimary_Border80BottomAfter:after,
    .colorPrimary_Border80BottomHoverBefore:hover:before,
    .colorPrimary_Border80BottomHoverBefore:active:before,
    .colorPrimary_Border80BottomHoverAfter:hover:after,
    .colorPrimary_Border80BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.8);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder80Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder80BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder80BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder80BottomActive {
        border-bottom-color: rgba(109,181,69,0.8) !important;
    }

    .colorPrimary_Border80Top,
    .colorPrimary_Border80TopHover:hover,
    .colorPrimary_Border80TopHover:active,
    .colorPrimary_Border80TopBefore:before,
    .colorPrimary_Border80TopAfter:after,
    .colorPrimary_Border80TopHoverBefore:hover:before,
    .colorPrimary_Border80TopHoverBefore:active:before,
    .colorPrimary_Border80TopHoverAfter:hover:after,
    .colorPrimary_Border80TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.8);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder80Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder80TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder80TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder80TopActive {
        border-top-color: rgba(109,181,69,0.8) !important;
    }

    .colorPrimary_Border80Right,
    .colorPrimary_Border80RightHover:hover,
    .colorPrimary_Border80RightHover:active,
    .colorPrimary_Border80RightBefore:before,
    .colorPrimary_Border80RightAfter:after,
    .colorPrimary_Border80RightHoverBefore:hover:before,
    .colorPrimary_Border80RightHoverBefore:active:before,
    .colorPrimary_Border80RightHoverAfter:hover:after,
    .colorPrimary_Border80RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.8);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder80Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder80RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder80RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder80RightActive {
        border-right-color: rgba(109,181,69,0.8) !important;
    }

    .colorPrimary_Border80Left,
    .colorPrimary_Border80LeftHover:hover,
    .colorPrimary_Border80LeftHover:active,
    .colorPrimary_Border80LeftBefore:before,
    .colorPrimary_Border80LeftAfter:after,
    .colorPrimary_Border80LeftHoverBefore:hover:before,
    .colorPrimary_Border80LeftHoverBefore:active:before,
    .colorPrimary_Border80LeftHoverAfter:hover:after,
    .colorPrimary_Border80LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.8);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder80Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder80LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder80LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder80LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder80LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder80LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder80LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder80LeftActive {
        border-left-color: rgba(109,181,69,0.8) !important;
    }

    /* -*-*-*-*-*-*-*-*-*-*-*- COULEUR DES BORDER OPACITE 90 -*-*-*-*-*-*-*-*-*-*-*- */

    .colorPrimary_Border90,
    .colorPrimary_Border90Hover:hover,
    .colorPrimary_Border90Hover:active,
    .colorPrimary_Border90Before:before,
    .colorPrimary_Border90After:after,
    .colorPrimary_Border90HoverBefore:hover:before,
    .colorPrimary_Border90HoverBefore:active:before,
    .colorPrimary_Border90HoverAfter:hover:after,
    .colorPrimary_Border90HoverAfter:active:after {
        border-color: rgba(109,181,69,0.9);
    }

    .selected.colorPrimary_Border90Active,
    .active.colorPrimary_Border90Active,
    .checked.colorPrimary_Border90Active,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90Hover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90Checked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90Hover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90Before:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90After:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90HoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90CheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90HoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90HoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90CheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90HoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder90Active,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder90Active,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder90Active {
        border-color: rgba(109,181,69,0.9) !important;
    }

    .colorPrimary_Border90Bottom,
    .colorPrimary_Border90BottomHover:hover,
    .colorPrimary_Border90BottomHover:active,
    .colorPrimary_Border90BottomBefore:before,
    .colorPrimary_Border90BottomAfter:after,
    .colorPrimary_Border90BottomHoverBefore:hover:before,
    .colorPrimary_Border90BottomHoverBefore:active:before,
    .colorPrimary_Border90BottomHoverAfter:hover:after,
    .colorPrimary_Border90BottomHoverAfter:active:after {
        border-bottom-color: rgba(109,181,69,0.9);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder90Bottom,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90BottomHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90BottomChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90BottomHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90BottomBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90BottomAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90BottomHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90BottomCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90BottomHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90BottomHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90BottomCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90BottomHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder90BottomActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder90BottomActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder90BottomActive {
        border-bottom-color: rgba(109,181,69,0.9) !important;
    }

    .colorPrimary_Border90Top,
    .colorPrimary_Border90TopHover:hover,
    .colorPrimary_Border90TopHover:active,
    .colorPrimary_Border90TopBefore:before,
    .colorPrimary_Border90TopAfter:after,
    .colorPrimary_Border90TopHoverBefore:hover:before,
    .colorPrimary_Border90TopHoverBefore:active:before,
    .colorPrimary_Border90TopHoverAfter:hover:after,
    .colorPrimary_Border90TopHoverAfter:active:after {
        border-top-color: rgba(109,181,69,0.9);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder90Top,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90TopHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90TopChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90TopHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90TopBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90TopAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90TopHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90TopCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90TopHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90TopHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90TopCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90TopHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder90TopActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder90TopActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder90TopActive {
        border-top-color: rgba(109,181,69,0.9) !important;
    }

    .colorPrimary_Border90Right,
    .colorPrimary_Border90RightHover:hover,
    .colorPrimary_Border90RightHover:active,
    .colorPrimary_Border90RightBefore:before,
    .colorPrimary_Border90RightAfter:after,
    .colorPrimary_Border90RightHoverBefore:hover:before,
    .colorPrimary_Border90RightHoverBefore:active:before,
    .colorPrimary_Border90RightHoverAfter:hover:after,
    .colorPrimary_Border90RightHoverAfter:active:after {
        border-right-color: rgba(109,181,69,0.9);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder90Right,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90RightHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90RightChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90RightHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90RightBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90RightAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90RightHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90RightCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90RightHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90RightHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90RightCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90RightHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder90RightActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder90RightActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder90RightActive {
        border-right-color: rgba(109,181,69,0.9) !important;
    }

    .colorPrimary_Border90Left,
    .colorPrimary_Border90LeftHover:hover,
    .colorPrimary_Border90LeftHover:active,
    .colorPrimary_Border90LeftBefore:before,
    .colorPrimary_Border90LeftAfter:after,
    .colorPrimary_Border90LeftHoverBefore:hover:before,
    .colorPrimary_Border90LeftHoverBefore:active:before,
    .colorPrimary_Border90LeftHoverAfter:hover:after,
    .colorPrimary_Border90LeftHoverAfter:active:after {
        border-left-color: rgba(109,181,69,0.9);
    }

    .colorPrimary_Parent .colorPrimary_EnfantBorder90Left,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90LeftHover,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90LeftChecked,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90LeftHover,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90LeftBefore:before,
    .colorPrimary_Parent .colorPrimary_EnfantBorder90LeftAfter:after,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90LeftHoverBefore:before,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90LeftCheckedBefore:before,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90LeftHoverBefore:before,
    .colorPrimary_Parent:hover .colorPrimary_EnfantBorder90LeftHoverAfter:after,
    .colorPrimary_Parent .colorPrimary_Index:checked + .colorPrimary_EnfantBorder90LeftCheckedAfter:after,
    .colorPrimary_Parent:active .colorPrimary_EnfantBorder90LeftHoverAfter:after,
    .selected.colorPrimary_Parent .colorPrimary_EnfantBorder90LeftActive,
    .active.colorPrimary_Parent .colorPrimary_EnfantBorder90LeftActive,
    .checked.colorPrimary_Parent .colorPrimary_EnfantBorder90LeftActive {
        border-left-color: rgba(109,181,69,0.9) !important;
    }

</style>

    <style>

    .timeline {
        list-style: none;
        padding: 20px;
        position: relative;
        z-index: 1;
    }

    .timeline:before {
        top: 0;
        position: absolute;
        content: '';
        width: 2px;
        height: 100%;
        background-color: #4b4b4b;
        left: calc(50% - 1px);
        z-index: -1;
    }

    .timeline .myLi, .timeline .timeline-item {
        margin-bottom: 20px;
        display: flex;
        justify-content: flex-start;
        z-index: 10;
    }
    .timeline .myLi {
        padding: 7px;
        margin: auto auto 20px auto;
        background: #4b4b4b;
        max-width: 150px;
        text-align: center;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center !important;
    }
    .timeline-badge {
        height: 0px;
        position: absolute;
        width: 0px;
        border-left: 55px solid transparent;
        border-top: 52px solid;
        right: 5px;
        top: 5px;
        color: #4b4b4b;
    }

    .timeline-heading {
        padding-bottom: 10px;
    }

    .timeline .timeline-item .timeline-panel {
        width: calc(50% - 30px);
        border: solid 1px #9c9c9c;
        border-radius: 1px;
        padding: 10px 20px 10px 10px;
        position: relative;
        background: #fff;
    }

    .timeline .timeline-item .timeline-panel:before {
        position: absolute;
        top: 26px;
        right: -15px;
        border-top: 15px solid transparent;
        border-left: 15px solid #9c9c9c;
        border-right: 0 solid #9c9c9c;
        border-bottom: 15px solid transparent;
        content: '';
    }

    .timeline > li > .timeline-panel:after {
        position: absolute;
        top: 27px;
        right: -14px;
        display: inline-block;
        border-top: 14px solid transparent;
        border-left: 14px solid #fff;
        border-right: 0 solid #fff;
        border-bottom: 14px solid transparent;
        content: " ";
    }

    .timeline > li > .timeline-badge {
        color: #fff;
        width: 50px;
        height: 50px;
        line-height: 50px;
        font-size: 1.4em;
        text-align: center;
        position: absolute;
        top: 16px;
        left: 50%;
        margin-left: -25px;
        background-color: #999999;
        z-index: 100;
        border-top-right-radius: 50%;
        border-top-left-radius: 50%;
        border-bottom-right-radius: 50%;
        border-bottom-left-radius: 50%;
    }

    .timeline > li.timeline-item.timeline-item-right {
        justify-content: flex-end;
    }

    .timeline > li.timeline-item.timeline-item-right > .timeline-panel:before {
        border-left-width: 0;
        border-right-width: 15px;
        left: -15px;
        right: auto;
    }

    .timeline > li.timeline-item.timeline-item-right > .timeline-panel:after {
        border-left-width: 0;
        border-right-width: 14px;
        left: -14px;
        right: auto;
    }

    .timeline-title {
        margin-top: 0;
        color: inherit;
        width: 90%;
        font-size: 14px;
    }

    .timeline-body {
        border-top: solid 1px #a0a0a0;
        padding-top: 12px;
        font-size: 14px;
    }

    .timeline-body > p,
    .timeline-body > ul {
        margin-bottom: 0;
    }

    .timeline-body > p + p {
        margin-top: 5px;
    }

    .timeline .timeline-badge-icon {
        position: absolute;
        top: -46px;
        left: -23px;
        color: white;
        font-size: 18px;
    }

    .timeline .timeline-avatar {
        width: 35px;
        height: 35px;
        margin-right: 10px;
        border-radius: 50%;
        object-fit: cover;
        float: left;
    }

    .timeline .timeline-cross {
        display: none;
    }

    @media screen and (max-width: 980px) {

        .timeline > li.timeline-item.timeline-item-right {
            justify-content: flex-start;
        }

        .timeline .myLi {
            margin: 0;
            margin-bottom: 20px;
        }

        ul.timeline:before {
            left: 40px;
        }

        .timeline .timeline-item .timeline-panel {
            width: calc(100% - 90px);
            width: -moz-calc(100% - 90px);
            width: -webkit-calc(100% - 90px);
            float: left;
            left: 75px;
        }

        .timeline > li.timeline-item.timeline-item-right > .timeline-panel {
            float: left;
            left: 75px;
        }

        ul.timeline .timeline-item .timeline-panel:before {
            border-left-width: 0;
            border-right-width: 15px;
            left: -15px;
            right: auto;
        }

        ul.timeline .timeline-item .timeline-panel:after {
            border-left-width: 0;
            border-right-width: 14px;
            left: -14px;
            right: auto;
        }
    }

    @media screen and (max-width: 580px) {
        .timeline {
            padding: 20px 0;
        }
        .timeline .myLi {
            margin: auto auto 20px auto;
        }
        ul.timeline .timeline-item .timeline-panel:after, ul.timeline .timeline-item .timeline-panel:before {
            display: none;
        }
        .timeline .timeline-item .timeline-panel {
            left: 0;
            width: 100%;
        }
        ul.timeline:before {
            left: 50%;
        }
        .timeline > li.timeline-item.timeline-item-right > .timeline-panel {
            left: 0;
        }
    }

</style>
        <div class="controlSizePage">
            <header class="headerECContainer">
    <div class="logoContainer">
        <img src="https://adroit-immobilier.la-boite-immo.com/images/logoadmin.jpg" alt=" - Logo Agence" class="logo">
    </div>
    <div class="textConnectionContainer transition250">
        <div class="topContainer">
            <h1 class="textStronger textConsigne">
                <span class="icon icon50-arrow-right-2"></span>
                <span class="textHeader">
                                            Connectez-vous à <span class="textBold">votre Espace Personnel !</span>
                                    </span>
            </h1>
                    </div>
        <div class="bottomContainer colorPrimary_BackgroundAfter disconnect">
                        <p class="textStronger textWelcome">
                Bonjour<br>
                <span>
                                            Madame, Monsieur
                                    </span>
            </p>
        </div>
    </div>
    <div class="burgerContainer">
        <button type="button" class="iconBurger transition250"></button>
    </div>
</header>
            <main class="containerPage">
                                    <p class="textSimpleNoContainer textColor">Profitez de votre espace personnel dédié, dialoguez avec votre agence, modifiez vos informations personnelles et bien plus encore !</p>
                                                                                    <div class="espaceTab">
    <div class="connexionEC bxrow">
                <div class="bxd12 formConnexion">
            <div class="contentEC">
                <h2 class="titleECColor colorPrimary_Color">connexion à votre espace personnel</h2>
                <p class="textEC">Entrez le mot de passe puis cliquez sur “Se connecter”.</p>
                <form id="form_connexion" class="formContainer spaceBetween" autocomplete="off">
                    <div class="formStructure">
                        <div class="fcontrol">
                            <label class="labelText" for="login">Votre adresse email</label>
                            <div class="inputContainer">
                                <span class="icon icon-mails-envoyes2"></span>
                                <input type="email" name="email" class="inputEC" autocomplete="nope" id="login" value="" required>
                            </div>
                        </div>
                        <div class="fcontrol">
                            <label class="labelText" for="password">Mot de passe</label>
                            <div class="inputContainer">
                                <span class="icon icon-cadenas-ferme"></span>
                                <span class="icon iconToSee icon39-eye"></span>
                                <input type="password" class="inputEC" autocomplete="new-password" name="password" id="password">
                            </div>
                        </div>
                    </div>
                    <div class="submitControl">
                        <button type="button" class="btnDefaultMin transition250 textStronger btnColorPrimaryBkg colorPrimary_Background" onclick="connexion()">Se connecter</button>
                        <button type="button" data-target="RecuperationEspacePerso" class="popinAppli forgetPassword colorPrimary_Color link">Mot de passe oublié ?</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function connexion() {
        var password = $j('#password').val();
        if (password === "") {
            $j('#password').closest('.inputContainer').addClass('verifNotOk');
        }
        var login = $j('#login').val();
        if (login === "") {
            $j('#login').closest('.inputContainer').addClass('verifNotOk');
        }
        if (login === "" || password === "") {
            return false;
        }

        $j.ajax({
            url: "/admin/?call=login",
            dataType: "json",
            type: "POST",
            data: {
                'call': 'authenticate',
                'panelClient': 2,
                'password': password,
                'login': login
            },
            success: function (data) {
                if (data.error) {
                    $j('#password').closest('.inputContainer').addClass('verifNotOk');
                    $j('#login').closest('.inputContainer').addClass('verifNotOk');
                    return false;
                }
                location.reload();
            }
        });

    }
</script>
                                                        <div class="contactECContainer">
                    <p class="text colorPrimary_Color">Vous ne voulez plus de contact avec cette agence ?</p>
                    <p class="text textColor">Pour ne plus recevoir de SMS ou d’Email de la part de cette agence, <button type="button" class="linkSimple popinAppli" data-target="BlockedCom">cliquez ici</button></p>
                                            <p class="rappelECText textColor">
                            Nous vous rappelons que conformément à l'article 40 de la loi n°78-17 du 6 janvier 1978 relative à l'informatique,<br>aux fichiers et libertés vous êtes en droit de modifier ou supprimer vos données personnelles.
                            <button type="button" class="linkSimple popinAppli" data-target="MyData">En savoir +</button>
                        </p>
                                    </div>
            </main>
            <footer class="footerECContainer">
    <div class="logoContainer">
        <img src="https://adroit-immobilier.la-boite-immo.com/images/logoadmin.jpg" class="logo" alt=" - Logo Agence">
    </div>
    <div class="infoDataContainer">
        <div class="adresseAgence">
            <h2 class="topText"></h2>
            <p class="simpleText"> - </p>
            <p class="simpleText"></p>
            <p class="simpleText"></p>
        </div>
        <div class="otherDataAgence">
                            <a href="" class="topText"></a>
                                                <p class="simpleText">&#169; 2024 - La Boite Immo</p>
        </div>
    </div>
</footer>

        </div>
        <span class="jsContainer">
            <img src="/external/img/admin/pix.gif" onload="openLab('labs_base.js', null, 'baseUiKit');openLab('labs_espaceEC.js', null, 'espaceClient');"/>
        </span>
    <div class="popinContainerDefault popinRecuperationEspacePerso hide">
    <div class="popinContentDefault">
        <div class="popinStucture">
                            <div class="popinImgContent">
                        <img src="/external/img/admin/espace_client/popinRecuperationEspacePerso.png" class="imgPopin colorPrimary_Background">
                </div>
                <div class="popinDataContent">
                        <h2 class="sousTitrePopin">
        récupération de<p class="titrePopin colorPrimary_Color">Mon espace personnel</p>
    </h2>
    <p class="textDefault_14_4 paragraphePopin light">
        Pas de panique ! Remplissez le formulaire ci-dessous et<br>nous vous enverrons par email les informations pour<br>vous créer un nouveau mot de passe.
    </p>
    <form class="formContainer spaceBetween" autocomplete="off">
        <div class="formStructure">
            <div class="js_bloc_mdp">
            </div>
            <div class="fcontrol">
                <label class="labelText" for="login_mdp">Votre adresse email</label>
                <div class="inputContainer">
                    <span class="icon icon-mails-envoyes2"></span>
                    <input type="email" id="login_mdp" name="login_mdp" autocomplete="nope" value="" class="inputEC" required>
                </div>
            </div>
        </div>
    </form>
    <div class="buttonContent">
        <button class="btnDefaultMin textDefault_16_4 transition250 btnColorPrimaryBkg colorPrimary_Background disabledBtn" onclick="recupererMonCompte()">Récupérer</button>
    </div>
    <script>
        function recupererMonCompte() {
            if($j('#login_mdp').val() === '') {
                $j('#login_mdp').attr('placeholder', 'Veuillez rentrer votre email');
                $j('#login_mdp').closest('.inputContainer').addClass('verifNotOk');
                $j('#login_mdp').closest('.inputContainer').find('.icon').css({display: 'none'});
                $j('#login_mdp').css({padding: '13px'});
                return false;
            }
            $j.ajax({
                url: "/admin/espace_client.php",
                dataType: "json",
                type: "POST",
                data: {
                    'call': 'ajax',
                    'mode': 'recuperationCompte',
                    'login': $j('#login_mdp').val()
                },
                success: function (data) {
                    if(data.error) {
                        $j("#login_mdp").attr('placeholder', 'Veuillez rentrer votre email');
                        $j("#login_mdp").closest('.inputContainer').addClass('verifNotOk');
                    }
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                }
            });
        }
    </script>
                </div>
                        <span class="iconClosePopin js_iconClosePopin icon55-fermer-light"></span>
        </div>
    </div>
</div>
    <div class="popinContainerDefault popinMyData hide">
    <div class="popinContentDefault">
        <div class="popinStucture">
                            <div class="popinImgContent">
                        <img src="/external/img/admin/espace_client/popinMyData.png" class="imgPopin colorPrimary_Background">
                </div>
                <div class="popinDataContent">
                        <h2 class="titrePopin colorPrimary_Color">Mes données</h2>
            <p class="textDefault_13_4 paragraphePopin">
            Nous vous rappelons que conformément à l'article 40 de la loi n°78-17 du 6 janvier 1978 relative à l'informatique, aux fichiers et aux libertés "toute personne physique justifiant de son identité peut exiger du responsable d'un traitement que soient, selon les cas, rectifiées, complétées, mises à jour, verrouillées ou effacées les données à caractère personnel la concernant, qui sont inexactes, incomplétes, équivoques, périmées, ou dont la collecte, l'utilisation, la communication ou la conservation est interdite".
        </p>
    
    <p class="sousTitrePopin">
        Consulter et modifier mes données personnelles
    </p>
    <p class="textDefault_13_4 paragraphePopin">
        Pour consulter ou modifier vos informations personnelles, activez votre espace personnel ou, si celui-ci est déjà activé, connectez-vous depuis le formulaire de connexion.
    </p>
    <p class="sousTitrePopin">
        Supprimer mes informations personnelles
    </p>
    <p class="textDefault_13_4 paragraphePopin">
        Pour vérifier les données personnelles recueillies par votre agence, connectez-vous à votre Espace personnel ou demandez directement la suppression de vos informations et l'arrêt de toute communication.
        Vos informations personnelles seront alors anonymisées.
        Seuls les documents déjà signés avec l'agence ne pourront pas être supprimés.
    </p>
    <div class="buttonContent">
        <button type="button" class="js_iconClosePopin btnDefaultMin textDefault_16_4 transition250 btnGreyBorder btnGreyBorder__element colorPrimary_Border colorPrimary_Color colorPrimary_BackgroundHover">Annuler</button>
        <button type="button" onclick="$j('.js_initialisation_compte').removeClass('hide');$j('.js_activation_compte').addClass('hide');" class="btnDefault textDefault_16_4 transition250 btnColorPrimaryBkg colorPrimary_Background js_iconClosePopin">
                            Me connecter
            </button>
        <button type="button" class="link transition250 textDefault_13_4 popinAppli" data-target="DemandeSuccess" onclick="callActionProspect('deleteData','1',);return false;">Supprimer mes données personnelles</button>
    </div>
                </div>
                        <span class="iconClosePopin js_iconClosePopin icon55-fermer-light"></span>
        </div>
    </div>
</div>
    <div class="popinContainerDefault popinBlockedCom hide">
    <div class="popinContentDefault">
        <div class="popinStucture">
                            <div class="popinImgContent">
                        <img src="/external/img/admin/espace_client/popinBlockedCom.png" class="imgPopin colorPrimary_Background">
                </div>
                <div class="popinDataContent">
                        <div class="textContent">
        <h2 class="sousTitrePopin">
            je souhaite<p class="titrePopin colorPrimary_Color">bloquer les communications</p>
        </h2>
        <p class="textDefault_14_4 paragraphePopin light">
            En validant cette opération vous ne permettez plus à<br>votre agence de vous envoyer des emails et des SMS.
        </p>
    </div>
    <div class="buttonContent">
        <button type="button" class="btnDefaultMin textDefault_16_4 transition250 btnGreyBorder btnGreyBorder__element colorPrimary_Border colorPrimary_Color colorPrimary_BackgroundHover js_iconClosePopin">Annuler</button>
        <button type="button" class="btnDefaultMin textDefault_16_4 transition250 btnColorPrimaryBkg colorPrimary_Background" onclick="callActionProspect('bloquerLesCommunication','ALL','');">Valider</button>
    </div>
                </div>
                        <span class="iconClosePopin js_iconClosePopin icon55-fermer-light"></span>
        </div>
    </div>
</div>
    <div class="popinContainerDefault popinDemandeSuccess hide">
    <div class="popinContentDefault">
        <div class="popinStucture">
                            <div class="popinImgContent">
                        <img src="/external/img/admin/espace_client/popinDemandeSuccess.png" class="imgPopin colorPrimary_Background">
                </div>
                <div class="popinDataContent">
                        <p class="sousTitrePopin">
        Votre demande a bien été<br>envoyée à votre agence !
    </p>
                </div>
                        <span class="iconClosePopin js_iconClosePopin icon55-fermer-light"></span>
        </div>
    </div>
</div>
    </body>
    <script>
        
        $j(document).ready(function(){
            $j(window.location.pathname.split('/')[2] ==='espace_proprietaire.php'?'.js_nav_proprio':'.js_nav_client').addClass('my-nav-active');
        });

        function load_ac_villesForAnnonce(callback, type, inputedId) {
            switch (inputedId) {
                case 'villepublique':
                    var inputed = $j("#villepublique");
                    var nameAfficher = "ouvillePublique";
                    var completed = $j('#codepublique');
                    var modifVille = false;
                    var idObjected = $j('#idObject' + type);
                    var typeObjected = $j('#typeObject' + type);
                    break;
                case 'villeprivee':
                    var inputed = $j("#villeprivee");
                    var nameAfficher = "ouvillePrivee";
                    var completed = $j('#codeprivee');
                    var modifVille = false;
                    var idObjected = $j('#idObject' + type);
                    var typeObjected = $j('#typeObject' + type);
                    break;
                case 'mandataire':
                case 'prospect':
                    var inputed = $j("#ville");
                    var nameAfficher = "ouville";
                    var completed = $j('#code');
                    var modifVille = false;
                    var idObjected = $j('#idObject' + type);
                    var typeObjected = $j('#typeObject' + type);
                    $j("#idVille").val('');
                    $j('#idCode').val('');
                    $j("#ville").val('');
                    $j('#code').val('');
                    break;
                default :
                    var inputed = $j("#" + inputedId);
                    var nameAfficher = "ouVilleRapp";
                    var modifVille = true;
                    var idObjected = $j('#idObject' + type + 'Prospect');
                    var typeObjected = $j('#typeObject' + type + 'Prospect');
            }


            var newAcq = false;
            var afficher = $j("#" + nameAfficher);
            inputed.on('keyup', function () {
                var inputVille = $j(this), value = inputVille.val(), countryVal = $j("#pays").val();
                var idPays = (document.getElementById('idPays') ? $j("#idPays").val() : $j("#idpays").val());
                var timer = timerGlobal;
                if (timer) {
                    clearTimeout(timer);
                }
                timerGlobal = setTimeout(function () {
                    if (value.length > 2) {
                        setWaiter(afficher);
                        var monscopeCode = completed.val();
                        afficher.load('?call=ac_villes', {
                            scope: 'ville',
                            ville: value,
                            scopeCode: monscopeCode,
                            wellformed: true,
                            idpays: idPays,
                            country: countryVal,
                            uCountry: true
                        }, function () {
                            afficher.show();
                            $j("#" + nameAfficher + " ul.villesBox li").hover(function () {
                                $j(this).addClass('selected');
                            }, function () {
                                $j(this).removeClass('selected');
                            }).on("click", function () {

                                var nomVille = $j('.humanName', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, ''), li = this;
                                var nomCodeName = $j('.nameCode', this).text();
                                var nomcode = $j('.code', this).text();

                                afficher.hide();
                                if (nomCodeName && nomCodeName !== '' && nomCodeName !== ' ' && nomCodeName !== null && nomCodeName !== 'null') {
                                    inputVille.val(nomVille + ' - ' + nomCodeName)
                                } else {
                                    inputVille.val(nomVille);
                                }

                                if (completed) {
                                    completed.val(nomcode);
                                }

                                if (callback && callback !== '') {
                                    callback.call(li);
                                } else {
                                    treatMyVille(li, idObjected, typeObjected, type, 'interne', newAcq, modifVille);
                                }

                                /*------*/
                                /*----GESTION DU QUARTIER POUR LICENCES LU ET AS--*/

                                if ($j('.listQuartier', this).length) {
                                    var listquartier = $j('.listQuartier', this).html().split('|');
                                    $j('#nfoQuartier').css('display', 'block');
                                    $j('#QUARTIER').html(createOptionsValues(listquartier));
                                } else {
                                    $j('#QUARTIER').html('<option value = "-aucun-" > -aucun - < /option>');
                                    $j('#nfoQuartier').css('display', 'none');
                                }

                            });

                            //get More City
                            if ($j("#" + nameAfficher + " #moreTownFromHA").length) {
                                $j("#" + nameAfficher + " #moreTownFromHA").on("click", function () {
                                    $j(this).remove();

                                    getMoreCityAnnonce(afficher, nameAfficher, value, idPays, inputed, idObjected, typeObjected, null, type, newAcq, modifVille);
                                });
                            }

                            if ($j("#" + nameAfficher + " #moreTownFromSelf").length) {
                                $j("#" + nameAfficher + " #moreTownFromSelf").on("click", function () {
                                    $j(this).remove();

                                    getMoreCitySelf(afficher, nameAfficher, value, idPays, inputed, idObjected, typeObjected, null, type, newAcq, modifVille);
                                });
                            }

                            $j("#" + nameAfficher + " ul.villesExternesBox li").hover(function () {
                                $j(this).addClass('selected');
                            }, function () {
                                $j(this).removeClass('selected');
                            }).on("click", function () {
                                var li = this;

                                var nomVille = $j('.Nom', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, '');
                                var nomCode = $j('.Code', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, '');
                                var Code = $j('.CodeNom', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, '');


                                inputVille.val(nomVille);
                                completed.val(Code);
                                bringTownHomeAnnonce(afficher, $j(this).attr('idVille'), $j(this).attr('idCode'), inputed, idObjected, typeObjected, li, type, newAcq, modifVille);

                            });
                        });
                    }
                }, 500);
            });
        }


        function setWaiter(who) {
            who.html('<div id = "waiterSetted" style="background:transparent url(/external/img/admin/ajax_loader_small.gif) no-repeat top left;margin:15px;width:33px;height:33px;">&nbsp;</div>');
            who.show();
        }


        function treatMyVille(item, idObjected, typeObjected, type, genre, newAcq, modifVille) {
            var retour = new Array();
            retour = getElementForLi(item);
            var inputIdCode = $j('#idCode' + type);
            var inputIdVille = $j('#idVille' + type);
            inputIdCode.val(retour['idVilleCode']);
            inputIdVille.val(retour['idVille']);

            var dataToSend = {
                mode: "villes-checkModelTypeGeo",
                idVille: retour['idVille'],
                idVilleCode: retour['idVilleCode'],
                genre: genre,
                newAcq: newAcq
            };
            $j.ajax({
                type: "GET",
                url: 'xmlrpc.php',
                data: dataToSend,
                dataType: 'json',
                success: function (data) {
                    idObjected.val(data.id);
                    typeObjected.val(data.type);
                    if (type === "publique") {
                        $j('#longitudeVille').val(retour['longitude']);
                        $j('#longitude').val(retour['longitude']);
                        $j('#latitudeVille').val(retour['latitude']);
                        $j('#latitude').val(retour['latitude']);
                    } else {
                        $j('#longitudeVille').val(retour['longitude']);
                        $j('#latitudeVille').val(retour['latitude']);
                        $j('#latitudeVilleprivee').val(retour['latitude']);
                        $j('#longitudeVilleprivee').val(retour['longitude']);
                    }

                    changeZones();
                }
            });
            changeAdresseMapSecteur();
        }

        function changeZones() {
            getZone('quartier');
            getZone('secteur');
        }

        function getZone(zone) {
            var idVille = $j("#idVilleprivee").val();
            var idCode = $j("#idCodeprivee").val();
            var idAnnonce = $j("#idAnnonce").val();
            var idProgrammeNeuf = $j("#current_pneuf_id").val();
            var more = "";
            if ($j("#idannWizard").val() > 0) {
                idAnnonce = $j("#idannWizard").val();
                more = "&wizard=1"
            }

            var url = 'mode=zones-affZonesVille&idVille=' + idVille + '&idCode=' + idCode + '&typezone=' + zone;
            if (idAnnonce) url += '&idAnnonce=' + idAnnonce + more;
            if (idProgrammeNeuf) url += '&idProgrammeNeuf=' + idProgrammeNeuf;
            lb_on()
            $j.ajax({
                type: "GET",
                url: "xmlrpc.php",
                data: url,
                success: function (data) {
                    lb_off();
                    $j("#bloc" + zone).html(data);
                    $j('.itemCheckBoxIhm' + zone).each(function () {
                        var rel = $j(this).attr('rel');
                        var chkRel = $j('#' + rel);
                        chkRel.on("click", function (event) {
                            event.stopPropagation();
                        });
                    });

                    $j('.itemCheckBoxIhm' + zone).on("click", function () {
                        var rel = $j(this).attr('rel');
                        var chkRel = $j('#' + rel);
                        if (chkRel.attr('checked')) {
                            chkRel.attr('checked', false);
                        } else {
                            chkRel.attr('checked', true);
                        }
                    });

                    $j('.itemCheckBoxIhm' + zone).on("mouseover", function () {
                        $j(this).css('background-color', '#FFF');
                    })
                    $j('.itemCheckBoxIhm' + zone).on("mouseout", function () {
                        $j(this).css('background-color', '#E0E0E0');
                    })
                }
            });
        }

        function getElementForLi(item) {

            var retour = new Array();

            var regex = new RegExp('[-0123456789.]*_idVille', 'i');
            var text = regex.exec(item.innerHTML);
            idVille = text[0].replace('_idVille', '');
            retour['idVille'] = idVille;


            regex = new RegExp('[-0123456789.]*_idVilleCode', 'i');
            text = regex.exec(item.innerHTML);
            idVilleCode = text[0].replace('_idVilleCode', '');
            retour['idVilleCode'] = idVilleCode;


            var regex = new RegExp('[-0123456789.]*_latitude', 'i');
            var text = regex.exec(item.innerHTML);
            latitude = text[0].replace('_latitude', '');
            retour['latitude'] = latitude;


            regex = new RegExp('[-0123456789.]*_longitude', 'i');
            text = regex.exec(item.innerHTML);
            longitude = text[0].replace('_longitude', '');
            retour['longitude'] = longitude;

            return retour;
        }


        function getMoreCityAnnonce(afficher, nameAfficher, villeValue, idPays, inputed, idObjected, typeObjected, li, type, newAcq, modifVille) {
            afficher.append('<div id = "waiterSetted" style = "background:transparent url(/external/img/admin/ajax_loader_small.gif) no-repeat top left;margin:15px;width:33px;height:33px;" > &nbsp; </div>');
            afficher.show();
            $j.ajax({
                url: '?call=ac_villes_ha',
                type: 'post',
                data: {
                    ville: villeValue,
                    idpays: idPays
                },
                success: function (response) {
                    $j('#' + afficher.attr("id") + ' #waiterSetted').remove();
                    fficher.find('#waiterSetted').remove();
                    afficher.append(response);
                    $j("#" + nameAfficher + " ul.villesExternesBox li").hover(function () {
                        $j(this).addClass('selected');
                    }, function () {
                        $j(this).removeClass('selected');
                    }).on("click", function () {
                        li = this;
                        bringTownHomeAnnonce(afficher, $j(this).attr('idVille'), $j(this).attr('idCode'), inputed, idObjected, typeObjected, li, type, newAcq, modifVille);
                    });
                },
                complete: function(){
                    killWaiter(afficher);
                }
            });
        }


        function bringTownHome(afficheur, externalIdVille, externalIdCode, whatInput, whatIdObject, whatObject, li, type, newAcq, modifVille) {
            //on call ajax ws
            //on get id / nom / lat / long en data properties et on mets ? jour le qui de quoi.
            var dataToSend = {
                mode: "villes-assocVilleFromHA",
                externalIdVille: externalIdVille,
                externalIdCode: externalIdCode
            };

            setWaiter(afficheur);
            $j.ajax({
                type: "GET",
                url: 'xmlrpc.php',
                data: dataToSend,
                dataType: 'json',
                success: function (data) {
                    if (data.error) {
                        $j.msgbox(data.error);
                    } else {

                        whatInput.val(data.name);
                        whatIdObject.val(data.id);
                        whatObject.val(data.type);
                        afficheur.hide();
                        treatMyItem(li, whatIdObject, whatObject, type, 'externe', newAcq, modifVille);
                    }
                    afficheur.hide();
                }
            });
            changeAdresseMapSecteur();
        }


        function load_ac_codesAnnonce(callback, type, inputedId) {
            var inputed = "";
            var completed = "";
            var nameAfficher = "";
            var modifVille = "";
            var idObjected = "";
            var typeObjected = "";

            switch (inputedId) {
                case 'codepublique':
                    inputed = $j("#codepublique");
                    completed = $j('#villepublique');
                    nameAfficher = "ouvilleCodePublique";
                    modifVille = false;
                    idObjected = $j('#idObject' + type);
                    typeObjected = $j('#typeObject' + type);
                    break;
                case 'codeprivee':
                    inputed = $j("#codeprivee");
                    completed = $j('#villeprivee');
                    nameAfficher = "ouvilleCodePrivee";
                    modifVille = false;
                    idObjected = $j('#idObject' + type);
                    typeObjected = $j('#typeObject' + type);
                    break;
                case 'prospect':
                    inputed = $j("#code");
                    nameAfficher = "ouvilleCode";
                    completed = $j('#ville');
                    modifVille = false;
                    idObjected = $j('#idObject' + type);
                    typeObjected = $j('#typeObject' + type);
                    break;
                default :
                    inputed = $j("#" + inputedId);
                    completed = null;
                    nameAfficher = "ouVilleRapp";
                    modifVille = true;
                    idObjected = $j('#idObject' + type + 'Prospect');
                    typeObjected = $j('#typeObject' + type + 'Prospect');
            }


            var newAcq = false;

            var afficher = $j("#" + nameAfficher);

            inputed.on('keyup', function () {
                var inputVille = $j(this), value = inputVille.val(), countryVal = $j("#pays").val();
                var idPays = (document.getElementById('idPays') ? $j("#idPays").val() : $j("#idpays").val());
                var timer = timerGlobal;
                if (timer) {
                    clearTimeout(timer);
                }

                timerGlobal = setTimeout(function () {
                    if (value.length > 2) {
                        setWaiter(afficher);
                        var monscopeVille = completed.val();
                        afficher.load('?call=ac_villes', {
                            scope: 'code',
                            ville: value,
                            scopeVille: monscopeVille,
                            wellformed: true,
                            idpays: idPays,
                            country: countryVal,
                            uCountry: true
                        }, function () {
                            afficher.show();
                            $j("#" + nameAfficher + " ul.villesBox li").hover(function () {
                                $j(this).addClass('selected');
                            }, function () {
                                $j(this).removeClass('selected');
                            }).on("click", function () {

                                var nomCode = $j('.code', this).text();
                                var nomCodeName = $j('.nameCode', this).text();
                                var nomVille = $j('.humanName', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, ''), li = this;

                                afficher.hide();

                                inputVille.val(nomCode);
                                if (completed) {
                                    if (nomCodeName && nomCodeName !== '' && nomCodeName !== ' ' && nomCodeName !== null && nomCodeName !== 'null') {
                                        completed.val(nomVille + ' - ' + nomCodeName);
                                    } else {
                                        completed.val(nomVille);
                                    }
                                }

                                if (callback && callback !== '') {
                                    callback.call(li);
                                } else {
                                    treatMyCode(li, idObjected, typeObjected, type, 'interne', newAcq, modifVille);
                                }

                                /*------*/
                                /*----GESTION DU QUARTIER POUR LICENCES LU ET AS--*/
                                if ($j('.listQuartier', this).length) {
                                    var listquartier = $j('.listQuartier', this).html().split('|');
                                    $j('#nfoQuartier').css('display', 'block');
                                    $j('#QUARTIER').html(createOptionsValues(listquartier));
                                } else {
                                    $j('#QUARTIER').html('< option value = "-aucun-" > -aucun - < /option>');
                                    $j('#nfoQuartier').css('display', 'none');
                                }


                            });


                            //get More City
                            if ($j("#" + nameAfficher + " #moreTownFromHA").length) {
                                $j("#" + nameAfficher + " #moreTownFromHA").on("click", function () {
                                    $j(this).remove();

                                    getMoreCityAnnonce(afficher, nameAfficher, value, idPays, inputed, idObjected, typeObjected, null, type, newAcq, modifVille);
                                });
                            }

                            if ($j("#" + nameAfficher + " #moreTownFromSelf").length) {
                                $j("#" + nameAfficher + " #moreTownFromSelf").on("click", function () {
                                    $j(this).remove();
                                    getMoreCitySelf(afficher, nameAfficher, value, idPays, inputed, idObjected, typeObjected, null, type, newAcq, modifVille);
                                });
                            }


                            $j("#" + nameAfficher + " ul.villesExternesBox li").hover(function () {
                                $j(this).addClass('selected');
                            }, function () {
                                $j(this).removeClass('selected');
                            }).on("click", function () {
                                //                        var nomVille = $j('.frontal', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, ''), li = this;
                                var li = this;
                                var nomVille = $j('.Nom', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, '');
                                var nomCode = $j('.Code', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, '');
                                var Code = $j('.CodeNom', this).text().replace(/\(\d{5}\)|^\s+|\s+$/g, '');

                                inputVille.val(nomVille);
                                completed.val(Code);


                                bringTownHomeAnnonce(afficher, $j(this).attr('idVille'), $j(this).attr('idCode'), inputed, idObjected, typeObjected, li, type, newAcq, modifVille);

                            });

                        });
                    }
                }, 500);
            });
        }


        function bringTownHomeAnnonce(afficheur, externalIdVille, externalIdCode, whatInput, whatIdObject, whatObject, li, type, newAcq, modifVille) {
            //on call ajax ws
            //on get id / nom / lat / long en data properties et on mets ? jour le qui de quoi.
            var dataToSend = {
                mode: "villes-assocVilleFromHA",
                externalIdVille: externalIdVille,
                externalIdCode: externalIdCode
            };

            var idObj = whatInput.attr('id');
            setWaiter(afficheur);


            $j.ajax({
                type: "GET",
                url: 'xmlrpc.php',
                data: dataToSend,
                dataType: 'json',
                success: function (data) {
                    if (data.error) {
                        $j.msgbox(data.error);
                    } else {
                        afficheur.hide();

                        var villeInput = $j('#ville' + type);
                        var codeInput = $j('#code' + type);
                        var villeIdInput = $j('#idVille' + type);
                        var codeIdInput = $j('#idCode' + type);


                        var nameCity = data.name;
                        if (data.nameCode !== null && data.nameCode !== 'null' && data.nameCode !== '') {
                            nameCity = nameCity + ' ' + data.nameCode;
                        }
                        if (data.code !== null && data.code !== 'null' && data.code !== '') {
                            codeInput.val(data.code);
                        }
                        villeInput.val(nameCity);
                        villeIdInput.val(data.idVille);
                        codeIdInput.val(data.idCode);
                        if ($j('#latitude').length) {
                            $j('#latitude').val(data.latitude);
                        }
                        if ($j('#longitude').length) {
                            $j('#longitude').val(data.longitude);
                        }


                        //                    treatMyVille(li, whatIdObject, whatObject, type, 'externe',newAcq,modifVille);

                    }
                    afficheur.hide();
                }
            });
            changeAdresseMapSecteur();
        }


        function treatMyCode(item, idObjected, typeObjected, type, genre, newAcq, modifVille) {
            var retour = new Array();
            retour = getElementForLi(item);
            var inputIdCode = $j('#idCode' + type);
            var inputIdVille = $j('#idVille' + type);
            inputIdCode.val(retour['idVilleCode']);
            inputIdVille.val(retour['idVille']);
            var dataToSend = {
                mode: "villes-checkModelTypeGeo",
                idVille: retour['idVille'],
                idVilleCode: retour['idVilleCode'],
                genre: genre,
                newAcq: newAcq
            };
            $j.ajax({
                type: "GET",
                url: 'xmlrpc.php',
                data: dataToSend,
                dataType: 'json',
                success: function (data) {
                    idObjected.val(data.id);
                    typeObjected.val(data.type);
                    if (type === "publique") {
                        $j('#longitudeVille').val(retour['longitude']);
                        $j('#longitude').val(retour['longitude']);
                        $j('#latitudeVille').val(retour['latitude']);
                        $j('#latitude').val(retour['latitude']);
                    } else {
                        $j('#longitudeVille').val(retour['longitude']);
                        $j('#latitudeVille').val(retour['latitude']);
                        $j('#latitudeVilleprivee').val(retour['latitude']);
                        $j('#longitudeVilleprivee').val(retour['longitude']);
                    }
                    changeZones();
                }
            });
            changeAdresseMapSecteur();
        }
            </script>
    <script>
        var dateElementClass = 'dateFrParameterv2';
        var timerGlobal;
        $j.when($j.ready).then(function () {
            $j('.dateFrParameterv2').datetimepicker({
                format: 'd-m-Y',
                timepicker: false,
                timepickerScrollbar: false
            });

            $j("[data-scrollbar]").mCustomScrollbar({axis: "y"});
            $j("[data-scrollbar]").mCustomScrollbar("scrollTo", "bottom", {
                scrollInertia: 300
            });

        });

        transFormatDateInEng = function (frFormatDate) {
            var year, month, day, tabDate;
            tabDate = frFormatDate.split('-');
            year = tabDate[2];
            month = tabDate[1];
            day = tabDate[0];
            return year + '-' + month + '-' + day;
        };


        function lb_on() {
            $j("#chargement").show(200);
        }

        function lb_off() {
            $j("#chargement").hide(200);
        }

        function ajaxLoader(element) {
            if (!element.find('.ajax-loader-container').length) {
                element.prepend('<div class="ajax-loader-container"><div class="ajax-loader-element"></div></div>');
            }
        }

        function ajaxLoaderRemove(element) {
            element.find('.ajax-loader-container').remove();
        }

        function ajaxLoaderRemoveAll() {
            $j('.ajax-loader-container').remove();
        }

        function resetFloatVal(elem) {
            var bloc = $j(elem).parent().children('input');
            var id = bloc.attr('id');
            var oldVal = document.getElementById(id).getAttribute("value");
            bloc.val('');
        }

        function validRequiredInput(id) {
            var base = '.requiredClass input,.requiredClass select';
            var champs = (id !== null && id !== undefined && id !== '' && id !== "") ? '#' + id + ' ' + base : base;
            var retour = true;
            $j(champs).each(function () {
                if ($j(this).val() === "" && $j(this).attr('type') !== 'hidden' && $j(this).attr('data-excludevalidation') !== '1') {
                    this.style.setProperty('background', '#f8ffca', 'important');
                    retour = false;
                } else {
                    this.style.setProperty('background', 'white', 'important');
                }
            });
            if (!retour) {
                $j.alert.open(
                    'error',
                    'Error',
                    'Veuillez compl&eacute;ter les informations du/des champ(s) indiqu&eacute;(s) en jaune.',
                    {ok: 'Ok'}
                );
                goToHeader();
            }
            return retour;
        }

        function goToHeader() {
            $j('html, body').animate({scrollTop: 0}, 1000);
        }

        function sauvegarderEtape(mode, mefGroups, etape, callback) {
            var serial = '';
            $j.each(mefGroups, function (k, mefGroupe) {
                serial += serializeMefGroup(mefGroupe);
            });

            if (validRequiredInput()) {
                $j.ajax({
                    url: "/admin/espace_client.php",
                    dataType: "json",
                    type: "POST",
                    data: "call=ajax&mode=" + mode + "&etape=" + etape + "&" + serial,
                    success: function (data) {
                        loadIHM('consluter', $j('.ihmStructure'));
                    }
                });
                return true;
            }
        }

        function serializeMefGroup(keyMefGroupe) {

            var serial = '';
            var msgAlert = '';
            $j('[group$="' + keyMefGroupe + '"]').each(function () {
                var name = $j(this).attr('name');
                if (name === undefined) {
                    return;
                }
                if ($j(this).attr('filter') === 'numeric' && $j(this).val() != '') {
                    var valeurNum = $j(this).val();
                    $j(this).val(valeurNum.replace(",", "."));
                    valeurNum = valeurNum.replace(" ", "");
                    valeurNum = valeurNum.replace(",", ".");
                    $j(this).val(valeurNum);
                    if (!isNumber($j(this).val())) {
                        msgAlert = _text('Un_ou_plusieurs_champs_doivent_etre_numerique_uniquement');
                        $j(this).css('color', "#d70000");
                    }
                }
                switch ($j(this).attr('type')) {
                    case "radio" :
                        if ($j(this).is(":checked")) {
                            serial = serial + $j(this).attr('name') + '=' + encodeURIComponent($j(this).val()) + "&";
                        }
                        break;
                    case "text" :
                        /**
                         * @todo => gestion ? revoir car erreur avec UTF8
                         */
                        var val = encodeURIComponent($j(this).val());
                        if ($j(this).hasClass(dateElementClass)) {
                            val = transFormatDateInEng(val);
                        }

                        /* Champs ? ne pas reformater (-> d?j? urlencode) */
                        var noEscapeFieldName = ['nom', 'telephone', 'portable', 'telephone[]', 'portable[]', 'fax', 'tel'];
                        if (jQuery.inArray($j(this).attr('name'), noEscapeFieldName) === -1) {
                            serial = serial + $j(this).attr('name') + '=' + encodeURIComponent($j(this).val()) + "&";
                        } else {
                            serial = serial + $j(this).attr('name') + '=' + val + "&";
                        }
                        break;
                    case 'checkbox':
                        if ($j(this).is(":checked")) {
                            serial = serial + $j(this).attr('name') + '=' + $j(this).val() + "&";
                        }
                        break;
                    case undefined :
                        serial = serial + $j(this).attr('name') + '=' + encodeURIComponent($j(this).val()) + "&";
                        break;
                    default :
                        if ($j(this).attr('type') !== 'textarea') {
                            serial = serial + $j(this).attr('name') + '=' + encodeURIComponent($j(this).val()) + "&";
                        }
                }

            });
            $j('textarea[group|="' + keyMefGroupe + '"]').each(function () {
                if ($j(this).attr('name') !== undefined) {

                    var idArea = $j(this).attr('id');
                    var fromtiny = '';

                    if (typeof tinyMCE !== "undefined" && tinyMCE.get(idArea)) {
                        fromtiny = encodeURIComponent(tinyMCE.get(idArea).getContent())
                    }
                    if (fromtiny !== '') {
                        serial = serial + idArea + '=' + fromtiny + "&";
                    } else {
                        var value = $j(this).val().replace(/\u20ac/g, '[[&euro;]]');
                        serial = serial + idArea + '=' + encodeURIComponent(value) + "&";
                    }
                }
            });

            if (msgAlert !== '') {
                $j.msgbox(msgAlert);
                return (false);
            } else {
                return ((serial));
            }
        }

        function jeVeuxUnNouveauMotDePass(idContact) {
            $j.confirm({
                title: 'Mot de passe oublié !',
                content: 'Souhaitez-vous r&eacute;initialiser le mot de passe?<br>(Vous recevrez un mail avec un nouveau lien de connexion.)',
                buttons: {
                    Valider: function () {
                        callActionProspect('jeVeuxUnNouveauMotDePass', 'remove', idContact)
                    },
                    Annuler: function () {
                    }
                }
            });
        }

        function callActionProspect(type, data, idContact) {
            if (data) {
                var dataToSend = {
                    call: "ajax",
                    mode: "actionsEspacePersonnel",
                    type: type,
                    data: data,
                    idContact: idContact
                };

                $j.ajax({
                    type: "POST",
                    url: "/admin/espace_client.php",
                    data: dataToSend,
                    dataType: 'json',
                    success: function (data) {
                        if (type === 'deleteData') {
                            window.location.href = '/admin/espace_client.php'
                        } else if (type === 'mailToAgence') {
                            $j.confirm({
                                title: 'Message &agrave; votre agence !',
                                content: 'Votre message a bien &eacute;t&eacute; envoy&eacute;.',
                                buttons: {
                                    Valider: function () {
                                        $j('#textAEnvoyerALagence').val('');
                                        location.reload();
                                    }
                                }
                            });
                        }
                        else {
                            location.reload();
                        }
                    }
                });
            }
        }

        function logout() {
            $j.ajax({
                url: "/admin/espace_client.php",
                dataType: "json",
                type: "GET",
                data: {
                    'call': 'ajax',
                    'mode': 'logout',
                },
                success: function (data) {
                    if (data.error) {
                        return false;
                    }
                    window.location.href = '/admin/espace_client.php'
                }
            });
        }




        function downloadDocument(id, type) {
            if (type == 'HektorModelModelDocumentSave') {
                var url = 'pdf.php?fiche_type=doc_type&id=' + id;
                var hauteur = 950;
                var largeur = 700;
                var haut = (screen.height - hauteur) / 2;
                var Gauche = (screen.width - largeur) / 2;
                var fencent = window.open(url, "pdf_doctype_" + id, "top=" + haut + ",left=" + Gauche + ",width=" + largeur + ",height=" + hauteur + ", toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no");
                if (fencent.window.focus) {
                    fencent.window.focus();
                }
            } else {
                $j.ajax({
                    url: "/admin/espace_client.php",
                    dataType: "json",
                    type: "GET",
                    data: {
                        'call': 'ajax',
                        'mode': 'download',
                        'type': type,
                        'id': id
                    },
                    success: function (data) {
                        if (data.error) {
                            return false;
                        }
                        top.location = '/admin/?call=force&path=' + data.payload.path + data.payload.filename + '&filename=' + data.payload.filename + '&humanname=' + data.payload.humanname;
                    }
                });
            }

        }

        function colorNavigation(element) {
            element.parent().addClass('nav-link-my-parent');
        }


    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.min.js"
            integrity="sha256-xaF9RpdtRxzwYMWg4ldJoyPWqyDPCRD0Cv7YEEe6Ie8=" crossorigin="anonymous"></script>
    <script src="/external/js/dropzone.js"></script>
    </html>
